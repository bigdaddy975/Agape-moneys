#!/bin/sh
! base58 -d 25 -c 111111111111111111114oLvT2 >/dev/null
