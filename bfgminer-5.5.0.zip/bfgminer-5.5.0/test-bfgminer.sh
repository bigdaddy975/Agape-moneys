#!/bin/sh
echo $PATH
bfgminer --unittest --no-default-config --scan noauto -d?
