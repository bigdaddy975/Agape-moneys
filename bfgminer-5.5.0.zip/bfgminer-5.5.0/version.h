#define BFG_GIT_DESCRIBE "bfgminer-5.5.0"
#ifdef VERSION
#  undef VERSION
#endif
#define VERSION "5.5.0"
