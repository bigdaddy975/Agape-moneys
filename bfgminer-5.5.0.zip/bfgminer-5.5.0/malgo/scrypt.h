#ifndef SCRYPT_H
#define SCRYPT_H

extern void test_scrypt(void);

#endif /* SCRYPT_H */
