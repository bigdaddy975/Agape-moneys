#!/bin/sh
# To avoid exit codes other than 0 or 1
./test || exit 1
