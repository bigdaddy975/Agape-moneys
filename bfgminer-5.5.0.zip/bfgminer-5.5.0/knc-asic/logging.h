#include <syslog.h>
extern int debug_level;
void applog(int level, char *fmt, ...);
